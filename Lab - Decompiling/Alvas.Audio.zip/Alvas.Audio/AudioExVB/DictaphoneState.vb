Imports System
Imports System.Text

Namespace AudioExCS
	Public Enum DictaphoneState
		Initial
		PausePlay
		Play
		PauseRecord
		Record
	End Enum
End Namespace
