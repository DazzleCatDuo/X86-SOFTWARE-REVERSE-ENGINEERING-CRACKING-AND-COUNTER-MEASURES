using System;
using System.Text;

namespace AudioExCS
{
    public enum DictaphoneState
    {
        Initial,
        PausePlay,
        Play,
        PauseRecord,
        Record,
    }
}
